import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau


def train_model(model, train_loader, val_loader, meta, num_epochs=50, lr=1e-3, device="cpu"):
    model.to(device)

    # Weighted cross-entropy to handle class imbalance
    criterion = nn.CrossEntropyLoss(weight=meta["class_weights"].to(device))
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)
    scheduler = ReduceLROnPlateau(
    optimizer,
    mode="min",
    patience=5,
    factor=0.5,
)
    best_val_loss = float("inf")
    best_state = None

    for epoch in range(1, num_epochs + 1):
        # ── Training ──────────────────────────────────────────
        model.train()
        train_loss, train_correct, train_total = 0.0, 0, 0

        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)

            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            train_loss    += loss.item() * len(y_batch)
            preds          = outputs.argmax(dim=1)
            train_correct += (preds == y_batch).sum().item()
            train_total   += len(y_batch)

        # ── Validation ────────────────────────────────────────
        model.eval()
        val_loss, val_correct, val_total = 0.0, 0, 0

        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                outputs    = model(X_batch)
                loss       = criterion(outputs, y_batch)
                val_loss  += loss.item() * len(y_batch)
                preds      = outputs.argmax(dim=1)
                val_correct += (preds == y_batch).sum().item()
                val_total  += len(y_batch)

        avg_train_loss = train_loss / train_total
        avg_val_loss   = val_loss   / val_total
        train_acc      = 100 * train_correct / train_total
        val_acc        = 100 * val_correct   / val_total

        scheduler.step(avg_val_loss)

        if epoch % 5 == 0 or epoch == 1:
            print(
                f"Epoch [{epoch:>3}/{num_epochs}]  "
                f"Train Loss: {avg_train_loss:.4f}  Acc: {train_acc:.2f}%  |  "
                f"Val Loss: {avg_val_loss:.4f}  Acc: {val_acc:.2f}%"
            )

        # Save best checkpoint
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            best_state = {k: v.clone() for k, v in model.state_dict().items()}

    # Restore best weights
    model.load_state_dict(best_state)
    print(f"\nBest validation loss: {best_val_loss:.4f}")
    return model
