import torch
from data_loader import get_data_loaders
from model import AttackDetectionNet
from train import train_model
from evaluate import evaluate_model

torch.manual_seed(42)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {DEVICE}\n")

# ── Load Data ─────────────────────────────────────────────────────────────────
train_loader, val_loader, test_loader, meta = get_data_loaders(batch_size=256)

# ── Build Model ───────────────────────────────────────────────────────────────
model = AttackDetectionNet(
    input_size=meta["input_size"],
    num_classes=meta["num_classes"],
    dropout=0.3,
)
print(f"Model input size: {meta['input_size']}  |  Classes: {meta['num_classes']}")
print(f"Attack classes: {meta['class_names']}\n")

# ── Train ─────────────────────────────────────────────────────────────────────
model = train_model(
    model, train_loader, val_loader, meta,
    num_epochs=50, lr=1e-3, device=DEVICE
)

# ── Evaluate ──────────────────────────────────────────────────────────────────
evaluate_model(model, test_loader, meta, device=DEVICE)

# ── Save ──────────────────────────────────────────────────────────────────────
torch.save({
    "model_state": model.state_dict(),
    "input_size": meta["input_size"],
    "num_classes": meta["num_classes"],
    "class_names": meta["class_names"],
    "feature_names": meta["feature_names"],
    "scaler": meta["scaler"],
    "label_encoder": meta["label_encoder"],
}, "attack_detection_model.pt")
print("\nModel saved to attack_detection_model.pt")