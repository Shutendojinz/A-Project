import torch
import pandas as pd
import joblib

from model import AttackDetectionNet
from data_loader import preprocess, load_and_merge_datasets, DATASET_PATHS
from elk_export import export_predictions_to_jsonl


DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_PATH = "attack_detection_model.pt"


def main():
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE, weights_only=False)

    model = AttackDetectionNet(
        input_size=checkpoint["input_size"],
        num_classes=checkpoint["num_classes"],
        dropout=0.3,
    )

    model.load_state_dict(checkpoint["model_state"])
    model.to(DEVICE)

    raw_df = load_and_merge_datasets(DATASET_PATHS)

    X, y, feature_names, label_encoder_from_data = preprocess(raw_df)

    export_predictions_to_jsonl(
        model=model,
        raw_df=raw_df,
        processed_X=X,
        scaler=checkpoint["scaler"],
        label_encoder=checkpoint["label_encoder"],
        output_path="logs/ai_attack_predictions.jsonl",
        device=DEVICE,
    )


if __name__ == "__main__":
    main()
