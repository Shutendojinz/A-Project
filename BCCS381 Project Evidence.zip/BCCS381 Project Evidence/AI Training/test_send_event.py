from elasticsearch import Elasticsearch
from datetime import datetime, timezone
import os


ELASTICSEARCH_URL = "https://myminicapstone-a6ec65.es.ap-southeast-2.aws.elastic.cloud:443"
INDEX_NAME = "ai-attack-detections-test"


def main():
    api_key = "essu_V0ZwWUxXbzFORUpuV0hSalUyVXlMVzVrTTI4NmMwbExjVVp1YjJOQ2JWRmtlV3BLWm5KRmFrSnlkdz09AAAAAOcJCgU="

    if not api_key:
        raise RuntimeError("Missing ELASTIC_API_KEY environment variable.")

    es = Elasticsearch(
        ELASTICSEARCH_URL,
        api_key=api_key,
        request_timeout=60,
    )

    event = {
        "@timestamp": datetime.now(timezone.utc).isoformat(),
        "source_dataset": "connection_test",
        "src_ip": "192.168.1.10",
        "dst_ip": "8.8.8.8",
        "protocol": "TCP",
        "prediction": "ATTACK",
        "confidence": 0.98,
        "attack_score": 0.98,
        "severity": "high",
        "model_name": "pytorch_attack_detector_test",
    }

    response = es.index(
        index=INDEX_NAME,
        document=event,
    )

    print("Event sent successfully.")
    print(response)


if __name__ == "__main__":
    main()
