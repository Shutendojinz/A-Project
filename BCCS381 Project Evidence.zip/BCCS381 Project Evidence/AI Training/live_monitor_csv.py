import time
import os
import json
from pathlib import Path
from datetime import datetime, timezone

import pandas as pd
import numpy as np
import torch
import torch.nn.functional as F
from elasticsearch import Elasticsearch, helpers

from model import AttackDetectionNet


ELASTICSEARCH_URL = "https://myminicapstone-a6ec65.es.ap-southeast-2.aws.elastic.cloud:443"
INDEX_NAME = "ai-live-attack-detections"

WATCH_FOLDER = Path("live_flows")
PROCESSED_FOLDER = Path("processed_flows")
MODEL_PATH = "attack_detection_model.pt"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def get_elasticsearch_client():
    api_key = "essu_V0ZwWUxXbzFORUpuV0hSalUyVXlMVzVrTTI4NmMwbExjVVp1YjJOQ2JWRmtlV3BLWm5KRmFrSnlkdz09AAAAAOcJCgU="

    if not api_key:
        raise RuntimeError("Missing ELASTIC_API_KEY environment variable.")

    return Elasticsearch(
        ELASTICSEARCH_URL,
        api_key=api_key,
        request_timeout=60,
    )


def severity_from_score(score: float) -> str:
    if score >= 0.90:
        return "critical"
    if score >= 0.75:
        return "high"
    if score >= 0.50:
        return "medium"
    return "low"


def get_optional_value(row, possible_columns, default="unknown"):
    for col in possible_columns:
        if col in row.index and pd.notna(row[col]):
            return row[col]
    return default


def prepare_live_features(raw_df: pd.DataFrame, feature_names: list[str]) -> pd.DataFrame:
    """
    Prepare live CSV rows so they match the exact training feature columns.
    Missing training features are filled with 0.
    Extra live columns are ignored.
    """
    df = raw_df.copy()

    drop_columns = [
        "Flow ID",
        "Src IP",
        "Dst IP",
        "Timestamp",
        "time",
        "src_ip",
        "dst_ip",
        "DeviceName",
        "Device_Name",
        "Attack",
        "AttacksubType",
        "Attack_subType",
        "Label",
        "label",
        "class",
        "spike_anomaly",
        "source_dataset",
    ]

    df = df.drop(columns=drop_columns, errors="ignore")
    df = df.replace([np.inf, -np.inf], np.nan)

    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    for feature in feature_names:
        if feature not in df.columns:
            df[feature] = 0

    df = df[feature_names]
    df = df.fillna(0)

    return df


def load_model():
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE, weights_only=False)

    model = AttackDetectionNet(
        input_size=checkpoint["input_size"],
        num_classes=checkpoint["num_classes"],
        dropout=0.3,
    )

    model.load_state_dict(checkpoint["model_state"])
    model.to(DEVICE)
    model.eval()

    return model, checkpoint


def predict_dataframe(model, checkpoint, raw_df: pd.DataFrame) -> list[dict]:
    feature_names = checkpoint["feature_names"]
    scaler = checkpoint["scaler"]
    label_encoder = checkpoint["label_encoder"]

    X_df = prepare_live_features(raw_df, feature_names)
    X_scaled = scaler.transform(X_df.values)

    X_tensor = torch.FloatTensor(X_scaled).to(DEVICE)

    with torch.no_grad():
        logits = model(X_tensor)
        probabilities = F.softmax(logits, dim=1)
        confidence_values, predicted_indices = probabilities.max(dim=1)

    predicted_indices = predicted_indices.cpu().numpy()
    confidence_values = confidence_values.cpu().numpy()
    predicted_labels = label_encoder.inverse_transform(predicted_indices)

    events = []

    for i, row in raw_df.iterrows():
        prediction = str(predicted_labels[i])
        confidence = float(confidence_values[i])

        attack_score = confidence if prediction == "ATTACK" else 1.0 - confidence

        event = {
            "@timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "virtual_environment_live_monitor",
            "prediction": prediction,
            "confidence": confidence,
            "attack_score": float(attack_score),
            "severity": severity_from_score(float(attack_score)),
            "model_name": "pytorch_attack_detector_live",

            "src_ip": str(get_optional_value(row, ["Src IP", "src_ip"])),
            "dst_ip": str(get_optional_value(row, ["Dst IP", "dst_ip"])),
            "src_port": str(get_optional_value(row, ["Src Port", "tcp_src_port"], "")),
            "dst_port": str(get_optional_value(row, ["Dst Port", "tcp_dst_port"], "")),
            "protocol": str(get_optional_value(row, ["Protocol", "protocol"])),
        }

        optional_fields = [
            "Flow Duration",
            "Tot Fwd Pkts",
            "Tot Bwd Pkts",
            "Flow Byts/s",
            "Flow Pkts/s",
            "packet_length",
            "ttl",
            "tcp_flags",
            "bandwidth",
            "jitter",
        ]

        for field in optional_fields:
            if field in row.index and pd.notna(row[field]):
                try:
                    event[field] = float(row[field])
                except ValueError:
                    event[field] = str(row[field])

        events.append(event)

    return events


def send_events(es, events: list[dict]):
    if not events:
        return

    actions = [
        {
            "_index": INDEX_NAME,
            "_source": event,
        }
        for event in events
    ]

    success, errors = helpers.bulk(
        es,
        actions,
        raise_on_error=False,
        request_timeout=60,
    )

    print(f"Sent {success} live events to Elasticsearch.")

    if errors:
        print(f"Failed events: {len(errors)}")


def monitor_folder():
    WATCH_FOLDER.mkdir(exist_ok=True)
    PROCESSED_FOLDER.mkdir(exist_ok=True)

    es = get_elasticsearch_client()
    model, checkpoint = load_model()

    print(f"Monitoring folder: {WATCH_FOLDER.resolve()}")
    print("Drop new flow CSV files into this folder.")
    print("Press Ctrl+C to stop.")

    processed_files = set()

    while True:
        csv_files = sorted(WATCH_FOLDER.glob("*.csv"))

        for csv_file in csv_files:
            if csv_file.name in processed_files:
                continue

            print(f"\nProcessing live flow file: {csv_file.name}")

            try:
                raw_df = pd.read_csv(csv_file, low_memory=False)

                if raw_df.empty:
                    print("CSV is empty, skipping.")
                    continue

                events = predict_dataframe(model, checkpoint, raw_df)
                send_events(es, events)

                target_path = PROCESSED_FOLDER / csv_file.name
                csv_file.rename(target_path)

                processed_files.add(csv_file.name)
                print(f"Moved processed file to: {target_path}")

            except Exception as exc:
                print(f"Error processing {csv_file.name}: {exc}")

        time.sleep(5)


if __name__ == "__main__":
    monitor_folder()
