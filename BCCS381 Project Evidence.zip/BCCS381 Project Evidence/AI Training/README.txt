SDN-IoT Intrusion Detection Dataset (ASEADOS-SDN-IoT)
------------------------------------------------------

a. Copyright
-------------
This ASEADOS-SDN-IoT dataset is an open-access resource available for all researchers.
It is licensed under an Attribution 4.0 International (CC BY 4.0) license.

If you are using this dataset, please cite the following paper:

Tharindu Lakshan Yasarathna, Nhien-An Le-Khac,
"ASEADOS-SDN-IoT: A Novel SDN-IoT Network Intrusion Detection Dataset,"

Paper link: https://doi.org/10.1016/j.iot.2026.101891

Dataset link: https://aseados.ucd.ie/datasets/SDN-IoT/


b. Dataset brief description
-----------------------------
The ASEADOS-SDN-IoT dataset is a comprehensive benchmark for evaluating intrusion detection systems (IDS)
in Software-Defined Networking (SDN) and Internet of Things (IoT) environments.
It captures both benign (normal) and malicious traffic generated in a realistic hybrid SDNâ€“IoT testbed that integrates:

- Physical IoT devices (Raspberry Pi boards and Amazon Echo devices) connected via a wireless access point.
- Virtual IoT nodes implemented in Mininet using Flask and Python scripts.
- An ONOS controller representing the SDN control plane.
- Open vSwitch (OVS) as the programmable data plane.
- A Metasploitable 2 server providing vulnerable IoT services.
- A Kali Linux VM used to generate attack traffic.

The dataset includes four major attack categories-DoS, DDoS, Probe, and Botnet--alongside normal traffic containing
web, DNS, FTP, SSH, and continuous IoT telemetry. The hybrid design (five logical OVS bridges) allowed the
simultaneous capture of data-plane traffic and control-plane telemetry using network packet capturing tools.


c. Dataset structure
---------------------
The dataset is organized into three main groups:

1. /Benign_IoT/
   - Contains normal IoT and user traffic (PCAP files).

2. /Benign_ONOS/
   - Controller telemetry captures and logs from ONOS (PCAP files).

3. /Attacks/
   - Includes DoS, DDoS, Botnet, and Probe attack traffic generated using tools such as Hping3, Hulk,
     Torshammer, SlowHTTPTest, BoNeSI, Nmap, and Metasploit (PCAP files).

All PCAP files were converted into flow records using CICFlowMeter, producing a single merged CSV file that
represents the final ASEADOS-SDN-IoT dataset. Each record is labeled as either Benign or one of the attack types.


d. Final labeled dataset summary
---------------------------------
Label               | Number of Flows | Percentage (%)
--------------------|-----------------|----------------
Benign (Normal)     | 260,797         | 57.06
DoS                 | 127,772         | 27.96
DDoS                | 51,465          | 11.26
Bot                 | 9,090           | 1.99
Probe               | 7,920           | 1.73
Total               | 457,044         | 100.00


e. Feature extraction and labeling
----------------------------------
Flow-based features were extracted using CICFlowMeter, which converts raw PCAP captures into bidirectional flows.
Each flow contains 83 statistical attributes covering duration, packet and byte counts, inter-arrival times,
header lengths, TCP flags, rates, and protocol information. Flows were labeled using source/destination IP addresses,
attack timestamps, and controller telemetry correlation from ONOS logs.
The final CSV dataset provides fully labeled flow records suitable for machine-learning and deep-learning model
training and evaluation.


f. Dataset format and statistics
--------------------------------
- Total flows: 457,044
- Normal flows: 260,797 (57.06%)
- Attack flows: 196,247 (42.94%)
- Number of features: 84
- File format: CSV


g. Licence
-----------
This dataset is distributed under the Creative Commons Attribution 4.0 International (CC BY 4.0) license.
Users may copy and modify the dataset for non-commercial research purposes, provided proper citation is given to the
original authors and publication.