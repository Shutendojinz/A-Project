from elasticsearch import Elasticsearch, helpers
import json
import os


ELASTICSEARCH_URL = "https://myminicapstone-a6ec65.es.ap-southeast-2.aws.elastic.cloud:443"
INDEX_NAME = "ai-attack-detections"


def send_jsonl_to_elasticsearch(jsonl_path: str):
    api_key = "essu_V0ZwWUxXbzFORUpuV0hSalUyVXlMVzVrTTI4NmMwbExjVVp1YjJOQ2JWRmtlV3BLWm5KRmFrSnlkdz09AAAAAOcJCgU="

    if not api_key:
        raise RuntimeError("Missing ELASTIC_API_KEY environment variable.")

    es = Elasticsearch(
        ELASTICSEARCH_URL,
        api_key=api_key,
        request_timeout=60,
    )

    if not es.ping():
        raise RuntimeError("Could not connect to Elastic Cloud. Check your endpoint and API key.")

    actions = []

    with open(jsonl_path, "r", encoding="utf-8") as file:
        for line in file:
            if not line.strip():
                continue

            document = json.loads(line)

            actions.append({
                "_index": INDEX_NAME,
                "_source": document,
            })

    if not actions:
        print("No events found to send.")
        return

    success, errors = helpers.bulk(
    es.options(request_timeout=60),
    actions,
    raise_on_error=False,
)


    print(f"Successfully sent {success} events to index: {INDEX_NAME}")

    if errors:
        print(f"Failed events: {len(errors)}")


if __name__ == "__main__":
    send_jsonl_to_elasticsearch("logs/ai_attack_predictions.jsonl")
