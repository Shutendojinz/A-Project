import json
from datetime import datetime, timezone
from pathlib import Path

import torch
import torch.nn.functional as F
import pandas as pd
import numpy as np


def severity_from_score(score: float) -> str:
    if score >= 0.90:
        return "critical"
    if score >= 0.75:
        return "high"
    if score >= 0.50:
        return "medium"
    return "low"


def get_optional_value(row, possible_columns, default=None):
    for col in possible_columns:
        if col in row.index:
            value = row[col]
            if pd.notna(value):
                return value
    return default


def export_predictions_to_jsonl(
    model,
    raw_df: pd.DataFrame,
    processed_X,
    scaler,
    label_encoder,
    output_path="logs/ai_attack_predictions.jsonl",
    device="cpu",
):
    """
    Run model predictions and export one JSON document per row.
    JSONL format works well with Logstash/Filebeat.
    """

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    model.eval()
    model.to(device)

    X_scaled = scaler.transform(processed_X)
    X_tensor = torch.FloatTensor(X_scaled).to(device)

    with torch.no_grad():
        logits = model(X_tensor)
        probabilities = F.softmax(logits, dim=1)
        confidence_values, predicted_indices = probabilities.max(dim=1)

    predicted_indices = predicted_indices.cpu().numpy()
    confidence_values = confidence_values.cpu().numpy()

    predicted_labels = label_encoder.inverse_transform(predicted_indices)

    with open(output_path, "w", encoding="utf-8") as file:
        for i, row in raw_df.iterrows():
            prediction = predicted_labels[i]
            confidence = float(confidence_values[i])

            src_ip = get_optional_value(row, ["Src IP", "src_ip", "source_ip", "ip.src"], "unknown")
            dst_ip = get_optional_value(row, ["Dst IP", "dst_ip", "destination_ip", "ip.dst"], "unknown")
            protocol = get_optional_value(row, ["Protocol", "protocol"], "unknown")

            event = {
                "@timestamp": datetime.now(timezone.utc).isoformat(),
                "source_dataset": get_optional_value(row, ["source_dataset"], "unknown"),
                "src_ip": str(src_ip),
                "dst_ip": str(dst_ip),
                "protocol": str(protocol),
                "prediction": str(prediction),
                "confidence": confidence,
                "attack_score": confidence if prediction == "ATTACK" else 1.0 - confidence,
                "severity": severity_from_score(confidence if prediction == "ATTACK" else 1.0 - confidence),
                "model_name": "pytorch_attack_detector",
            }

            optional_numeric_columns = [
                "packet_length",
                "Flow Duration",
                "Tot Fwd Pkts",
                "Tot Bwd Pkts",
                "Src Port",
                "Dst Port",
                "tcp_src_port",
                "tcp_dst_port",
                "ttl",
                "window_size",
                "bandwidth",
                "jitter",
                "total_data",
                "session_duration",
            ]

            for col in optional_numeric_columns:
                if col in row.index and pd.notna(row[col]):
                    try:
                        event[col] = float(row[col])
                    except ValueError:
                        event[col] = str(row[col])

            file.write(json.dumps(event) + "\n")

    print(f"Exported predictions to {output_path}")
