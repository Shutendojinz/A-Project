import pandas as pd
import numpy as np
import torch

from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
from torch.utils.data import Dataset, DataLoader


DATASET_PATHS = [
    "ASEADOS_SDN_IoT.csv",
    "BoTNeTIoT-L01-v2.csv",
    "Captured_packets.csv",
    "snmp_local_A.csv",
    "snmp_local_B.csv",
    "snmp_local_C.csv",
    "snmp_local_D.csv",
]


POSSIBLE_LABEL_COLUMNS = [
    "label",
    "Label",
    "LABEL",
    "class",
    "Class",
    "CLASS",
    "attack",
    "Attack",
    "type",
    "Type",
    "category",
    "Category",
    "target",
    "Target",
    "spike_anomaly",
    "Spike_Anomaly",
    "spike anomaly",
]


def find_label_column(df: pd.DataFrame, path: str) -> str:
    """
    Try to automatically detect the label column.
    """
    for col in POSSIBLE_LABEL_COLUMNS:
        if col in df.columns:
            return col

    raise ValueError(
        f"No label column found in {path}.\n"
        f"Available columns are:\n{list(df.columns)}\n\n"
        f"Rename your label column to 'label' or add it to POSSIBLE_LABEL_COLUMNS."
    )


def load_and_merge_datasets(paths: list[str]) -> pd.DataFrame:
    """
    Load all CSV files, detect their label column, standardize it to 'label',
    and merge everything into one DataFrame.
    """
    frames = []

    for path in paths:
        csv_path = Path(path)

        if not csv_path.exists():
            print(f"[WARNING] File not found, skipping: {path}")
            continue

        print(f"Loading: {path}")
        df = pd.read_csv(csv_path, low_memory=False)

        label_col = find_label_column(df, path)

        if label_col != "label":
            df = df.rename(columns={label_col: "label"})

        df["source_dataset"] = csv_path.stem

        print(f"  Shape: {df.shape}")
        print(f"  Label column: {label_col}")
        print(f"  Labels: {df['label'].astype(str).unique()[:10]}")

        frames.append(df)

    if not frames:
        raise RuntimeError("No CSV files were loaded. Check DATASET_PATHS.")

    combined = pd.concat(frames, axis=0, ignore_index=True, sort=False)

    print("\nCombined dataset:")
    print(combined.shape)

    return combined


def normalize_labels(y_raw: pd.Series) -> pd.Series:
    """
    Convert all dataset labels into binary classes:
        NORMAL
        ATTACK
    """

    y = y_raw.astype(str).str.strip().str.upper()

    normal_values = {
        "0",
        "0.0",
        "NORMAL",
        "BENIGN",
        "LEGITIMATE",
        "NO ATTACK",
        "NO_ATTACK",
        "REGULAR",
        "FALSE",
    }

    attack_values = {
        "1",
        "1.0",
        "ATTACK",
        "MALICIOUS",
        "ANOMALY",
        "SPIKE",
        "TRUE",
    }

    return y.apply(
        lambda value: "NORMAL"
        if value in normal_values
        else "ATTACK"
        if value in attack_values
        else "ATTACK"
    )




def preprocess(df: pd.DataFrame):
    """
    Clean, encode, and prepare the merged network dataset.
    Handles numeric and categorical traffic columns.
    """

    if "label" not in df.columns:
        raise ValueError("Merged dataset does not contain a 'label' column.")

    df = df.dropna(subset=["label"])

    y_raw = normalize_labels(df["label"])

    X_df = df.drop(columns=["label"])

    drop_columns = [
        # Wireshark identifiers
        "Flow ID",
        "Src IP",
        "Dst IP",
        "Timestamp",

        # Captured_packets identifiers
        "time",
        "src_ip",
        "dst_ip",

        # BotNet identifier/category columns
        "DeviceName",
        "Device_Name",
        "Attack",
        "AttacksubType",
        "Attack_subType",

        # Internal source column
        "source_dataset",
    ]

    X_df = X_df.drop(columns=drop_columns, errors="ignore")

    # Replace infinity values first
    X_df = X_df.replace([np.inf, -np.inf], np.nan)

    # Try to convert columns to numeric where possible.
    # If conversion fails, keep the column as text so it can be one-hot encoded later.
    for col in X_df.columns:
        try:
            X_df[col] = pd.to_numeric(X_df[col], errors="raise")
        except (ValueError, TypeError):
            X_df[col] = X_df[col].astype(str)


    # Identify categorical columns that remain as text
    categorical_columns = X_df.select_dtypes(include=["object", "category", "bool"]).columns.tolist()

    # One-hot encode categorical columns such as protocol and tcp_flags
    if categorical_columns:
        print("\nCategorical columns encoded:")
        print(categorical_columns)

        X_df = pd.get_dummies(
            X_df,
            columns=categorical_columns,
            dummy_na=True,
        )

    # Convert everything to numeric after encoding
    for col in X_df.columns:
        X_df[col] = pd.to_numeric(X_df[col], errors="coerce")

    X_df = X_df.select_dtypes(include=[np.number])
    X_df = X_df.replace([np.inf, -np.inf], np.nan)
    X_df = X_df.dropna(axis=1, how="all")
    X_df = X_df.fillna(X_df.median(numeric_only=True))
    X_df = X_df.loc[:, X_df.nunique(dropna=False) > 1]

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_raw)

    print("\nPreprocessing complete")
    print(f"Rows: {X_df.shape[0]}")
    print(f"Features used: {X_df.shape[1]}")
    print(f"Classes: {list(label_encoder.classes_)}")

    print("\nClass distribution:")
    print(pd.Series(label_encoder.inverse_transform(y)).value_counts())

    print("\nFeature columns used:")
    print(list(X_df.columns))

    return X_df.values, y, list(X_df.columns), label_encoder


class NetworkTrafficDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.FloatTensor(X)
        self.y = torch.LongTensor(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return self.X[index], self.y[index]


def safe_train_test_split(X, y, test_size, random_state):
    """
    Stratified split can fail if a class has very few samples.
    This falls back to normal splitting if needed.
    """
    try:
        return train_test_split(
            X,
            y,
            test_size=test_size,
            random_state=random_state,
            stratify=y,
        )
    except ValueError:
        print("[WARNING] Stratified split failed. Using non-stratified split.")
        return train_test_split(
            X,
            y,
            test_size=test_size,
            random_state=random_state,
            stratify=None,
        )


def get_data_loaders(batch_size: int = 256, test_size: float = 0.2, val_size: float = 0.1):
    df = load_and_merge_datasets(DATASET_PATHS)

    X, y, feature_names, label_encoder = preprocess(df)

    X_train, X_test, y_train, y_test = safe_train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=42,
    )

    relative_val_size = val_size / (1 - test_size)

    X_train, X_val, y_train, y_val = safe_train_test_split(
        X_train,
        y_train,
        test_size=relative_val_size,
        random_state=42,
    )

    scaler = StandardScaler()

    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    class_weights = compute_class_weight(
        class_weight="balanced",
        classes=np.unique(y_train),
        y=y_train,
    )

    class_weights = torch.FloatTensor(class_weights)

    train_dataset = NetworkTrafficDataset(X_train, y_train)
    val_dataset = NetworkTrafficDataset(X_val, y_val)
    test_dataset = NetworkTrafficDataset(X_test, y_test)

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
    )

    meta = {
        "input_size": X_train.shape[1],
        "num_classes": len(label_encoder.classes_),
        "class_names": list(label_encoder.classes_),
        "feature_names": feature_names,
        "label_encoder": label_encoder,
        "scaler": scaler,
        "class_weights": class_weights,
    }

    return train_loader, val_loader, test_loader, meta
