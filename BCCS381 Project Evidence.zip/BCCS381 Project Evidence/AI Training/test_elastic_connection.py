from elasticsearch import Elasticsearch
import os


ELASTICSEARCH_URL = "https://myminicapstone-a6ec65.es.ap-southeast-2.aws.elastic.cloud:443"


def main():
    api_key = "essu_V0ZwWUxXbzFORUpuV0hSalUyVXlMVzVrTTI4NmMwbExjVVp1YjJOQ2JWRmtlV3BLWm5KRmFrSnlkdz09AAAAAOcJCgU="

    if not api_key:
        raise RuntimeError("Missing ELASTIC_API_KEY environment variable.")

    es = Elasticsearch(
        ELASTICSEARCH_URL,
        api_key=api_key,
        request_timeout=60,
    )

    info = es.info()

    print("Connected to Elasticsearch successfully.")
    print(info)


if __name__ == "__main__":
    main()
