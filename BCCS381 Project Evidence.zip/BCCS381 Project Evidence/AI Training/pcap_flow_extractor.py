from __future__ import annotations

import argparse
import math
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scapy.all import rdpcap, IP, TCP, UDP


TCP_FLAG_FIN = 0x01
TCP_FLAG_SYN = 0x02
TCP_FLAG_RST = 0x04
TCP_FLAG_PSH = 0x08
TCP_FLAG_ACK = 0x10
TCP_FLAG_URG = 0x20
TCP_FLAG_ECE = 0x40
TCP_FLAG_CWR = 0x80


def safe_mean(values: list[float]) -> float:
    return float(np.mean(values)) if values else 0.0


def safe_std(values: list[float]) -> float:
    return float(np.std(values, ddof=0)) if values else 0.0


def safe_var(values: list[float]) -> float:
    return float(np.var(values, ddof=0)) if values else 0.0


def safe_min(values: list[float]) -> float:
    return float(np.min(values)) if values else 0.0


def safe_max(values: list[float]) -> float:
    return float(np.max(values)) if values else 0.0


@dataclass
class DirectionStats:
    packet_lengths: list[int] = field(default_factory=list)
    timestamps: list[float] = field(default_factory=list)
    total_bytes: int = 0
    header_len_total: int = 0
    psh_flags: int = 0
    urg_flags: int = 0
    act_data_pkts: int = 0
    init_window_bytes: int = 0
    seen_first_window: bool = False

    def add_packet(
        self,
        ts: float,
        pkt_len: int,
        header_len: int,
        tcp_flags: int = 0,
        payload_len: int = 0,
        tcp_window: int = 0,
    ) -> None:
        self.packet_lengths.append(pkt_len)
        self.timestamps.append(ts)
        self.total_bytes += pkt_len
        self.header_len_total += header_len

        if tcp_flags & TCP_FLAG_PSH:
            self.psh_flags += 1
        if tcp_flags & TCP_FLAG_URG:
            self.urg_flags += 1
        if payload_len > 0:
            self.act_data_pkts += 1

        if not self.seen_first_window:
            self.init_window_bytes = tcp_window
            self.seen_first_window = True

    @property
    def pkt_count(self) -> int:
        return len(self.packet_lengths)

    def inter_arrival_times(self) -> list[float]:
        if len(self.timestamps) < 2:
            return []
        return [
            self.timestamps[i] - self.timestamps[i - 1]
            for i in range(1, len(self.timestamps))
        ]


@dataclass
class Flow:
    src_ip: str
    src_port: int
    dst_ip: str
    dst_port: int
    protocol: int
    start_time: float
    first_seen_ts: float

    fwd: DirectionStats = field(default_factory=DirectionStats)
    bwd: DirectionStats = field(default_factory=DirectionStats)

    all_packet_lengths: list[int] = field(default_factory=list)
    all_timestamps: list[float] = field(default_factory=list)

    syn_flag_cnt: int = 0
    rst_flag_cnt: int = 0
    ack_flag_cnt: int = 0
    fin_flag_cnt: int = 0
    ece_flag_cnt: int = 0
    cwe_flag_count: int = 0

    last_seen_ts: float = 0.0

    def add_packet(
        self,
        ts: float,
        direction: str,
        pkt_len: int,
        header_len: int,
        tcp_flags: int = 0,
        payload_len: int = 0,
        tcp_window: int = 0,
    ) -> None:
        self.last_seen_ts = ts
        self.all_packet_lengths.append(pkt_len)
        self.all_timestamps.append(ts)

        if tcp_flags & TCP_FLAG_SYN:
            self.syn_flag_cnt += 1
        if tcp_flags & TCP_FLAG_RST:
            self.rst_flag_cnt += 1
        if tcp_flags & TCP_FLAG_ACK:
            self.ack_flag_cnt += 1
        if tcp_flags & TCP_FLAG_FIN:
            self.fin_flag_cnt += 1
        if tcp_flags & TCP_FLAG_ECE:
            self.ece_flag_cnt += 1
        if tcp_flags & TCP_FLAG_CWR:
            self.cwe_flag_count += 1

        if direction == "fwd":
            self.fwd.add_packet(ts, pkt_len, header_len, tcp_flags, payload_len, tcp_window)
        else:
            self.bwd.add_packet(ts, pkt_len, header_len, tcp_flags, payload_len, tcp_window)

    def flow_duration(self) -> float:
        return max(0.0, self.last_seen_ts - self.start_time)

    def flow_iat(self) -> list[float]:
        if len(self.all_timestamps) < 2:
            return []
        return [
            self.all_timestamps[i] - self.all_timestamps[i - 1]
            for i in range(1, len(self.all_timestamps))
        ]

    def active_idle_times(self, idle_threshold: float = 1.0) -> tuple[list[float], list[float]]:
        """
        Split times into active and idle periods using a simple threshold.
        """
        if len(self.all_timestamps) < 2:
            return [], []

        active_periods = []
        idle_periods = []

        current_active_start = self.all_timestamps[0]
        prev_ts = self.all_timestamps[0]

        for ts in self.all_timestamps[1:]:
            gap = ts - prev_ts
            if gap > idle_threshold:
                active_periods.append(prev_ts - current_active_start)
                idle_periods.append(gap)
                current_active_start = ts
            prev_ts = ts

        active_periods.append(prev_ts - current_active_start)
        return active_periods, idle_periods

    def to_record(self) -> dict:
        duration = self.flow_duration()
        total_pkts = self.fwd.pkt_count + self.bwd.pkt_count
        total_bytes = self.fwd.total_bytes + self.bwd.total_bytes

        flow_iat = self.flow_iat()
        fwd_iat = self.fwd.inter_arrival_times()
        bwd_iat = self.bwd.inter_arrival_times()

        active_times, idle_times = self.active_idle_times(idle_threshold=1.0)

        pkt_len_min = safe_min(self.all_packet_lengths)
        pkt_len_max = safe_max(self.all_packet_lengths)
        pkt_len_mean = safe_mean(self.all_packet_lengths)
        pkt_len_std = safe_std(self.all_packet_lengths)
        pkt_len_var = safe_var(self.all_packet_lengths)

        fwd_mean = safe_mean(self.fwd.packet_lengths)
        bwd_mean = safe_mean(self.bwd.packet_lengths)

        flow_byts_per_s = (total_bytes / duration) if duration > 0 else 0.0
        flow_pkts_per_s = (total_pkts / duration) if duration > 0 else 0.0
        fwd_pkts_per_s = (self.fwd.pkt_count / duration) if duration > 0 else 0.0
        bwd_pkts_per_s = (self.bwd.pkt_count / duration) if duration > 0 else 0.0

        down_up_ratio = (self.bwd.pkt_count / self.fwd.pkt_count) if self.fwd.pkt_count > 0 else 0.0

        return {
            "Flow ID": f"{self.src_ip}-{self.src_port}-{self.dst_ip}-{self.dst_port}-{self.protocol}",
            "Src IP": self.src_ip,
            "Src Port": self.src_port,
            "Dst IP": self.dst_ip,
            "Dst Port": self.dst_port,
            "Protocol": self.protocol,
            "Timestamp": self.first_seen_ts,

            "Flow Duration": duration,
            "Tot Fwd Pkts": self.fwd.pkt_count,
            "Tot Bwd Pkts": self.bwd.pkt_count,
            "TotLen Fwd Pkts": self.fwd.total_bytes,
            "TotLen Bwd Pkts": self.bwd.total_bytes,

            "Fwd Pkt Len Max": safe_max(self.fwd.packet_lengths),
            "Fwd Pkt Len Min": safe_min(self.fwd.packet_lengths),
            "Fwd Pkt Len Mean": fwd_mean,
            "Fwd Pkt Len Std": safe_std(self.fwd.packet_lengths),

            "Bwd Pkt Len Max": safe_max(self.bwd.packet_lengths),
            "Bwd Pkt Len Min": safe_min(self.bwd.packet_lengths),
            "Bwd Pkt Len Mean": bwd_mean,
            "Bwd Pkt Len Std": safe_std(self.bwd.packet_lengths),

            "Flow Byts/s": flow_byts_per_s,
            "Flow Pkts/s": flow_pkts_per_s,

            "Flow IAT Mean": safe_mean(flow_iat),
            "Flow IAT Std": safe_std(flow_iat),
            "Flow IAT Max": safe_max(flow_iat),
            "Flow IAT Min": safe_min(flow_iat),

            "Fwd IAT Tot": sum(fwd_iat) if fwd_iat else 0.0,
            "Fwd IAT Mean": safe_mean(fwd_iat),
            "Fwd IAT Std": safe_std(fwd_iat),
            "Fwd IAT Max": safe_max(fwd_iat),
            "Fwd IAT Min": safe_min(fwd_iat),

            "Bwd IAT Tot": sum(bwd_iat) if bwd_iat else 0.0,
            "Bwd IAT Mean": safe_mean(bwd_iat),
            "Bwd IAT Std": safe_std(bwd_iat),
            "Bwd IAT Max": safe_max(bwd_iat),
            "Bwd IAT Min": safe_min(bwd_iat),

            "Fwd PSH Flags": self.fwd.psh_flags,
            "Bwd PSH Flags": self.bwd.psh_flags,
            "Fwd URG Flags": self.fwd.urg_flags,
            "Bwd URG Flags": self.bwd.urg_flags,

            "Fwd Header Len": self.fwd.header_len_total,
            "Bwd Header Len": self.bwd.header_len_total,

            "Fwd Pkts/s": fwd_pkts_per_s,
            "Bwd Pkts/s": bwd_pkts_per_s,

            "Pkt Len Min": pkt_len_min,
            "Pkt Len Max": pkt_len_max,
            "Pkt Len Mean": pkt_len_mean,
            "Pkt Len Std": pkt_len_std,
            "Pkt Len Var": pkt_len_var,

            "FIN Flag Cnt": self.fin_flag_cnt,
            "SYN Flag Cnt": self.syn_flag_cnt,
            "RST Flag Cnt": self.rst_flag_cnt,
            "PSH Flag Cnt": self.fwd.psh_flags + self.bwd.psh_flags,
            "ACK Flag Cnt": self.ack_flag_cnt,
            "URG Flag Cnt": self.fwd.urg_flags + self.bwd.urg_flags,
            "CWE Flag Count": self.cwe_flag_count,
            "ECE Flag Cnt": self.ece_flag_cnt,

            "Down/Up Ratio": down_up_ratio,
            "Pkt Size Avg": pkt_len_mean,
            "Fwd Seg Size Avg": fwd_mean,
            "Bwd Seg Size Avg": bwd_mean,

            "Subflow Fwd Pkts": self.fwd.pkt_count,
            "Subflow Fwd Byts": self.fwd.total_bytes,
            "Subflow Bwd Pkts": self.bwd.pkt_count,
            "Subflow Bwd Byts": self.bwd.total_bytes,

            "Init Fwd Win Byts": self.fwd.init_window_bytes,
            "Init Bwd Win Byts": self.bwd.init_window_bytes,
            "Fwd Act Data Pkts": self.fwd.act_data_pkts,
            "Fwd Seg Size Min": safe_min(self.fwd.packet_lengths),

            "Active Mean": safe_mean(active_times),
            "Active Std": safe_std(active_times),
            "Active Max": safe_max(active_times),
            "Active Min": safe_min(active_times),

            "Idle Mean": safe_mean(idle_times),
            "Idle Std": safe_std(idle_times),
            "Idle Max": safe_max(idle_times),
            "Idle Min": safe_min(idle_times),
        }


def protocol_number(pkt) -> int:
    if TCP in pkt:
        return 6
    if UDP in pkt:
        return 17
    return int(pkt[IP].proto) if IP in pkt else 0


def get_ports(pkt) -> tuple[int, int]:
    if TCP in pkt:
        return int(pkt[TCP].sport), int(pkt[TCP].dport)
    if UDP in pkt:
        return int(pkt[UDP].sport), int(pkt[UDP].dport)
    return 0, 0


def packet_header_len(pkt) -> int:
    if IP not in pkt:
        return 0
    ip_header_len = int(pkt[IP].ihl) * 4 if hasattr(pkt[IP], "ihl") else 20
    if TCP in pkt:
        tcp_header_len = int(pkt[TCP].dataofs) * 4 if hasattr(pkt[TCP], "dataofs") and pkt[TCP].dataofs else 20
        return ip_header_len + tcp_header_len
    if UDP in pkt:
        return ip_header_len + 8
    return ip_header_len


def packet_payload_len(pkt) -> int:
    try:
        if TCP in pkt:
            ip_total_len = int(pkt[IP].len) if hasattr(pkt[IP], "len") and pkt[IP].len else len(bytes(pkt[IP]))
            headers = packet_header_len(pkt)
            return max(0, ip_total_len - headers)
        if UDP in pkt:
            udp_len = int(pkt[UDP].len) if hasattr(pkt[UDP], "len") and pkt[UDP].len else len(bytes(pkt[UDP]))
            return max(0, udp_len - 8)
    except Exception:
        return 0
    return 0


def packet_tcp_flags(pkt) -> int:
    if TCP in pkt:
        return int(pkt[TCP].flags)
    return 0


def packet_tcp_window(pkt) -> int:
    if TCP in pkt and hasattr(pkt[TCP], "window"):
        return int(pkt[TCP].window)
    return 0


def canonical_flow_key(src_ip: str, src_port: int, dst_ip: str, dst_port: int, proto: int):
    a = (src_ip, src_port)
    b = (dst_ip, dst_port)
    if a <= b:
        return (src_ip, src_port, dst_ip, dst_port, proto), "fwd"
    return (dst_ip, dst_port, src_ip, src_port, proto), "bwd"


def extract_flows_from_pcap(input_path: str | Path, output_csv: str | Path) -> pd.DataFrame:
    input_path = Path(input_path)
    output_csv = Path(output_csv)

    packets = rdpcap(str(input_path))
    flows: dict[tuple, Flow] = {}

    for pkt in packets:
        if IP not in pkt:
            continue

        src_ip = pkt[IP].src
        dst_ip = pkt[IP].dst
        proto = protocol_number(pkt)
        src_port, dst_port = get_ports(pkt)

        ts = float(pkt.time)
        pkt_len = int(len(pkt))
        header_len = packet_header_len(pkt)
        tcp_flags = packet_tcp_flags(pkt)
        payload_len = packet_payload_len(pkt)
        tcp_window = packet_tcp_window(pkt)

        key, direction = canonical_flow_key(src_ip, src_port, dst_ip, dst_port, proto)

        if key not in flows:
            flows[key] = Flow(
                src_ip=key[0],
                src_port=key[1],
                dst_ip=key[2],
                dst_port=key[3],
                protocol=key[4],
                start_time=ts,
                first_seen_ts=ts,
                last_seen_ts=ts,
            )

        flows[key].add_packet(
            ts=ts,
            direction=direction,
            pkt_len=pkt_len,
            header_len=header_len,
            tcp_flags=tcp_flags,
            payload_len=payload_len,
            tcp_window=tcp_window,
        )

    records = [flow.to_record() for flow in flows.values()]
    df = pd.DataFrame(records)

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_csv, index=False)

    return df


def main():
    parser = argparse.ArgumentParser(description="Extract simple bidirectional flow features from a PCAP/PCAPNG file.")
    parser.add_argument("input_pcap", help="Path to input .pcap or .pcapng file")
    parser.add_argument("output_csv", help="Path to output CSV file")
    args = parser.parse_args()

    df = extract_flows_from_pcap(args.input_pcap, args.output_csv)

    print(f"Extracted {len(df)} flows")
    print(f"Saved CSV to: {args.output_csv}")
    if not df.empty:
        print("\nColumns:")
        print(list(df.columns))


if __name__ == "__main__":
    main()
